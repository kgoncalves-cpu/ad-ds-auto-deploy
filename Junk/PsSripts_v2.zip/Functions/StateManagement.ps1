<#
.SYNOPSIS
    Gerenciamento de Estado - Rastreia execu��o das fases do deployment
.DESCRIPTION
    Mant�m registro do estado do deployment para automa��o das pr�ximas fases
#>

class DeploymentState {
    [string] $StateFilePath
    [hashtable] $State
    
    DeploymentState([string]$stateFile) {
        $this.StateFilePath = $stateFile
        $this.LoadState()
    }
    
    [void] LoadState() {
        if (Test-Path $this.StateFilePath) {
            try {
                $this.State = Import-Clixml -Path $this.StateFilePath
            } catch {
                $this.State = @{
                    Phase = 0
                    LastRun = $null
                    RenameApplied = $false
                    ADInstalled = $false
                    ADPromoted = $false
                }
            }
        } else {
            $this.State = @{
                Phase = 0
                LastRun = $null
                RenameApplied = $false
                ADInstalled = $false
                ADPromoted = $false
            }
        }
    }
    
    [void] SaveState() {
        $stateDir = Split-Path -Parent $this.StateFilePath
        if (-not (Test-Path $stateDir)) {
            New-Item -ItemType Directory -Path $stateDir -Force | Out-Null
        }
        
        $this.State | Export-Clixml -Path $this.StateFilePath -Force
    }
    
    [int] GetPhase() {
        return $this.State.Phase
    }
    
    [void] SetPhase([int]$phase) {
        $this.State.Phase = $phase
        $this.State.LastRun = Get-Date
        $this.SaveState()
    }
    
    [bool] IsRenameApplied() {
        return $this.State.RenameApplied
    }
    
    [void] MarkRenameApplied() {
        $this.State.RenameApplied = $true
        $this.SaveState()
    }
    
    [bool] IsADInstalled() {
        return $this.State.ADInstalled
    }
    
    [void] MarkADInstalled() {
        $this.State.ADInstalled = $true
        $this.SaveState()
    }
    
    [bool] IsADPromoted() {
        return $this.State.ADPromoted
    }
    
    [void] MarkADPromoted() {
        $this.State.ADPromoted = $true
        $this.SaveState()
    }
}

Export-ModuleMember -Class DeploymentState