#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Script wrapper para execu��o autom�tica ap�s reboot
.DESCRIPTION
    Este script � registrado no RunOnce para executar automaticamente
    ap�s o reboot do rename do servidor.
.NOTES
    Vers�o: 1.0
#>

param(
    [string]$ConfigFile = "$PSScriptRoot\Config\Default.psd1",
    [string]$Mode = "Interactive",
    [switch]$AutoContinue
)

Write-Host "`n" + ("=" * 64) -ForegroundColor Green
Write-Host "EXECU��O AUTOM�TICA - RESUMINDO AP�S REBOOT" -ForegroundColor Green
Write-Host ("=" * 64) -ForegroundColor Green

# Aguardar um pouco para garantir que tudo est� pronto
Start-Sleep -Seconds 5

# Executar Deploy.ps1 com os mesmos par�metros
& "$PSScriptRoot\Deploy.ps1" -ConfigFile $ConfigFile -Mode $Mode -AutoContinue:$AutoContinue