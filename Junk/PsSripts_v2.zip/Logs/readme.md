﻿Abordagem Module-Based + Configuration-as-Data + Dependency Injection

📁 Estrutura de Diretórios

📁 ADDeployment/
├── 📄 Deploy.ps1                    (Script Principal)
├── 📄 Deploy-Part2.ps1              (Parte 2 - Pós-Instalação)
├── 📁 Modules/
│   ├── 📄 ADDeployment.Core.psm1    (Núcleo)
│   ├── 📄 ADDeployment.Config.psm1  (Gerenciamento de Config)
│   ├── 📄 ADDeployment.Network.psm1 (Configurações de Rede)
│   ├── 📄 ADDeployment.Install.psm1 (Instalação do AD)
│   ├── 📄 ADDeployment.Setup.psm1   (Configuração Pós-AD)
│   └── 📄 ADDeployment.Validate.psm1(Validação)
├── 📁 Functions/
│   ├── 📄 Logging.ps1               (Funções de Log)
│   ├── 📄 Validation.ps1            (Validadores)
│   └── 📄 Utilities.ps1             (Utilitários)
├── 📁 Config/
│   ├── 📄 Default.psd1              (Padrão)
│   ├── 📄 Test.psd1                 (Teste)
│   └── 📄 Production.psd1           (Produção)
└── 📁 Logs/
    └── 📄 ADDeployment_*.log

🚀 Fluxo de Execução

Execução 1 (Manual):
  ├─ Deploy.ps1 -AutoContinue
  ├─ Fase 1-2: Rename
  ├─ Registra em RunOnce + Task Scheduler
  └─ REBOOT #1 (automático)

Execução 2 (Automática - RunOnce ou Task Scheduler):
  ├─ Deploy.ps1 (retomado automaticamente)
  ├─ Detecta rename já aplicado
  ├─ Fase 2: Configura IP
  ├─ Fase 3: Instala AD + Promove DC
  └─ REBOOT #2 (automático do AD)

Execução 3 (Manual):
  ├─ Deploy-Part2.ps1
  └─ Pós-configuração